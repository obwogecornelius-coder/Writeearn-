# WriteEarn – Freelancing & Online Writing Platform

Full-stack freelancing platform with real SQLite backend (Python standard library only).

## Features

- Responsive homepage (navy / white / gold)
- Registration, login, logout
- 3 initial writing tasks ($22 / $27 / $25)
- Writing workspace with word count + draft
- Earnings dashboard (Pending / Approved / Withdrawable)
- $100 minimum withdrawal threshold
- Bronze / Premium / Gold packages (M-PESA Till 5656584)
- Manual M-PESA payment + verification flow
- Task marketplace (unlocked after package)
- Withdrawal system
- Full Admin dashboard

## Run Locally

```bash
python3 app.py
```

Open http://localhost:8080

**Admin login:** `admin@platform.local` / `admin123`

---

## Deploy to Render (Recommended – Free)

1. Go to https://render.com and sign up (GitHub login is easiest).

2. Click **New +** → **Web Service**.

3. Connect a GitHub repository that contains these files  
   (create a new empty repo on GitHub → upload all files from this folder).

4. Configure the service:

   | Setting              | Value                          |
   |----------------------|--------------------------------|
   | Name                 | writeearn (or any name)        |
   | Runtime              | Python 3                       |
   | Build Command        | echo "No build needed"         |
   | Start Command        | python3 app.py                 |
   | Instance Type        | Free                           |

5. Click **Create Web Service**.

6. Wait 1–2 minutes. You will get a public URL like:
   `https://writeearn-xxxx.onrender.com`

### Important notes about Free tier

- The free instance sleeps after ~15 minutes of inactivity (first request after sleep takes 30–50 seconds).
- SQLite is stored in `/tmp` → data resets when the service restarts. Fine for demos.

---

## Deploy to Railway

1. Go to https://railway.app
2. New Project → Deploy from GitHub
3. Start command: `python3 app.py`
4. Railway sets the PORT automatically.

---

## Default Admin Account

- Email: `admin@platform.local`
- Password: `admin123`

Change this after first login.

## Project Structure

```
freelance-platform/
├── app.py
├── templates/
├── static/css/style.css
├── requirements.txt
├── Procfile
└── README.md
```
