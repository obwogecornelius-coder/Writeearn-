#!/usr/bin/env python3
"""
Freelancing & Online Writing Platform
Complete functional backend with SQLite database using only Python standard library.
"""

import os
import sys
import json
import sqlite3
import hashlib
import hmac
import secrets
import time
import datetime
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from http.cookies import SimpleCookie
import html
import re

# Configuration
HOST = "0.0.0.0"
PORT = int(os.environ.get("PORT", 8080))
SECRET_KEY = os.environ.get("SECRET_KEY", secrets.token_hex(32))
# Use /tmp for ephemeral filesystems (Render, Railway, etc.)
DB_PATH = os.environ.get("DB_PATH", "/tmp/writeearn_platform.db")
SESSION_DIR = os.environ.get("SESSION_DIR", "/tmp/writeearn_sessions")
TEMPLATES_DIR = os.path.join(os.path.dirname(__file__), "templates")
STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")

os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
os.makedirs(SESSION_DIR, exist_ok=True)

# ============== DATABASE ==============
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()

    c.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name TEXT NOT NULL,
        phone TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        package TEXT DEFAULT 'none',
        package_activated INTEGER DEFAULT 0,
        is_admin INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        category TEXT,
        instructions TEXT NOT NULL,
        reward_usd REAL NOT NULL,
        deadline_hours INTEGER DEFAULT 48,
        requirements TEXT,
        is_initial INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS task_submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        task_id INTEGER NOT NULL,
        content TEXT NOT NULL,
        word_count INTEGER,
        status TEXT DEFAULT 'pending',  -- pending, approved, rejected
        submitted_at TEXT DEFAULT CURRENT_TIMESTAMP,
        reviewed_at TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (task_id) REFERENCES tasks(id),
        UNIQUE(user_id, task_id)
    );

    CREATE TABLE IF NOT EXISTS earnings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        task_id INTEGER,
        submission_id INTEGER,
        amount_usd REAL NOT NULL,
        status TEXT DEFAULT 'pending',  -- pending, approved, paid
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        package TEXT NOT NULL,
        amount_ksh REAL NOT NULL,
        mpesa_code TEXT,
        phone TEXT,
        full_name TEXT,
        status TEXT DEFAULT 'pending',  -- pending, verified, rejected
        submitted_at TEXT DEFAULT CURRENT_TIMESTAMP,
        verified_at TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS withdrawals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        full_name TEXT NOT NULL,
        mpesa_phone TEXT NOT NULL,
        amount_usd REAL NOT NULL,
        status TEXT DEFAULT 'pending',  -- pending, processing, paid, rejected
        requested_at TEXT DEFAULT CURRENT_TIMESTAMP,
        processed_at TEXT,
        notes TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        message TEXT NOT NULL,
        is_read INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
    """)

    # Seed initial tasks if empty
    count = c.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
    if count == 0:
        initial_tasks = [
            ("Environmental Protection and the Future of Our Planet", "ENVIRONMENT",
             "Write an article discussing environmental protection, pollution, climate change and practical ways individuals can protect the environment.",
             22.0, 1, "Minimum 500 words. Original content. Proper structure with introduction, body and conclusion."),
            ("The Importance of Maintaining Good Health", "HEALTH",
             "Write an article explaining the importance of physical and mental wellbeing, healthy habits and preventive healthcare.",
             27.0, 1, "Minimum 500 words. Original content. Include practical tips."),
            ("Understanding the Effects of Drugs on Individuals and Society", "EFFECTS OF DRUGS",
             "Write an educational article discussing the potential effects of drug use on health, families and communities, and the importance of prevention and support.",
             25.0, 1, "Minimum 500 words. Educational tone. Original research-based content."),
        ]
        for t in initial_tasks:
            c.execute("""INSERT INTO tasks (title, category, instructions, reward_usd, is_initial, requirements)
                         VALUES (?, ?, ?, ?, ?, ?)""", t)

        # Additional marketplace tasks (demo / illustration)
        extra = [
            ("Blog Post: Remote Work Productivity Tips", "Blog writing", "Write a 600-word blog post on productivity tips for remote workers.", 18.0, 0, "SEO friendly, engaging tone."),
            ("Product Description Copywriting", "Copywriting", "Write compelling product descriptions for an e-commerce fashion store (5 products).", 15.0, 0, "Persuasive language, benefits focused."),
            ("Data Entry: Contact List Cleanup", "Data entry", "Clean and format a provided contact list of 200 entries.", 12.0, 0, "Accuracy required, Excel format."),
            ("Article: Benefits of Meditation", "Article writing", "Write a 700-word article on the science-backed benefits of daily meditation.", 20.0, 0, "Cite sources if possible."),
            ("Proofreading: Academic Essay", "Proofreading", "Proofread and correct a 1500-word academic essay for grammar and clarity.", 10.0, 0, "Track changes or detailed notes."),
            ("Online Research: Market Trends 2025", "Online research", "Research and summarize top 5 market trends in digital marketing for 2025.", 22.0, 0, "Include sources and key statistics."),
            ("Transcription: 10-min Interview", "Transcription", "Transcribe a 10-minute audio interview accurately.", 14.0, 0, "Timestamp every 30 seconds."),
            ("Document Formatting: Report", "Document formatting", "Format a business report into professional Word/PDF layout.", 11.0, 0, "Consistent styles, table of contents."),
        ]
        for t in extra:
            c.execute("""INSERT INTO tasks (title, category, instructions, reward_usd, is_initial, requirements)
                         VALUES (?, ?, ?, ?, ?, ?)""", t)

        # Create default admin
        admin_hash = hash_password("admin123")
        c.execute("""INSERT INTO users (full_name, phone, email, password_hash, is_admin, package, package_activated)
                     VALUES (?, ?, ?, ?, 1, 'gold', 1)""",
                  ("Platform Admin", "0700000000", "admin@platform.local", admin_hash))

    conn.commit()
    conn.close()
    print("Database initialized.")

def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100000)
    return salt + ":" + h.hex()

def verify_password(password: str, stored: str) -> bool:
    try:
        salt, h = stored.split(":")
        new_h = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100000)
        return hmac.compare_digest(new_h.hex(), h)
    except Exception:
        return False

# ============== SESSION ==============
def create_session(user_id: int) -> str:
    sid = secrets.token_hex(24)
    path = os.path.join(SESSION_DIR, sid)
    with open(path, "w") as f:
        json.dump({"user_id": user_id, "created": time.time()}, f)
    return sid

def get_session(sid: str):
    if not sid:
        return None
    path = os.path.join(SESSION_DIR, sid)
    if not os.path.exists(path):
        return None
    try:
        with open(path) as f:
            data = json.load(f)
        if time.time() - data.get("created", 0) > 86400 * 7:  # 7 days
            os.remove(path)
            return None
        return data
    except Exception:
        return None

def destroy_session(sid: str):
    path = os.path.join(SESSION_DIR, sid)
    if os.path.exists(path):
        os.remove(path)

# ============== HELPERS ==============
def render_template(name: str, **ctx) -> str:
    path = os.path.join(TEMPLATES_DIR, name)
    if not os.path.exists(path):
        return f"<h1>Template missing: {name}</h1>"
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    # Simple {{ var }} replacement
    for k, v in ctx.items():
        content = content.replace("{{ " + k + " }}", str(v) if v is not None else "")
        content = content.replace("{{" + k + "}}", str(v) if v is not None else "")
    # Simple {% if %} not fully supported; we pass pre-rendered sections
    return content

def get_user(user_id: int):
    conn = get_db()
    row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    return dict(row) if row else None

def get_earnings_summary(user_id: int):
    conn = get_db()
    rows = conn.execute("""
        SELECT status, SUM(amount_usd) as total FROM earnings
        WHERE user_id = ? GROUP BY status
    """, (user_id,)).fetchall()
    summary = {"pending": 0.0, "approved": 0.0, "paid": 0.0}
    for r in rows:
        summary[r["status"]] = r["total"] or 0.0
    # Withdrawable = approved
    summary["withdrawable"] = summary["approved"]
    conn.close()
    return summary

def user_completed_initial(user_id: int) -> bool:
    conn = get_db()
    count = conn.execute("""
        SELECT COUNT(*) FROM task_submissions ts
        JOIN tasks t ON ts.task_id = t.id
        WHERE ts.user_id = ? AND t.is_initial = 1 AND ts.status IN ('pending', 'approved')
    """, (user_id,)).fetchone()[0]
    conn.close()
    return count >= 3

# ============== REQUEST HANDLER ==============
class PlatformHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        print(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] {args[0]}")

    def parse_path(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)
        return path, query

    def get_post_data(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length).decode("utf-8") if length else ""
        if self.headers.get("Content-Type", "").startswith("application/json"):
            try:
                return json.loads(raw)
            except Exception:
                return {}
        return urllib.parse.parse_qs(raw)

    def get_cookie(self, name):
        cookie = SimpleCookie(self.headers.get("Cookie", ""))
        if name in cookie:
            return cookie[name].value
        return None

    def set_cookie(self, name, value, max_age=86400*7):
        self.send_header("Set-Cookie", f"{name}={value}; Path=/; Max-Age={max_age}; HttpOnly")

    def clear_cookie(self, name):
        self.send_header("Set-Cookie", f"{name}=; Path=/; Max-Age=0")

    def send_html(self, content, status=200):
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(content.encode("utf-8"))

    def send_redirect(self, location):
        self.send_response(302)
        self.send_header("Location", location)
        self.end_headers()

    def send_json(self, data, status=200):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

    def send_static(self, path):
        full = os.path.join(STATIC_DIR, path.lstrip("/static/"))
        if not os.path.exists(full) or not os.path.isfile(full):
            self.send_error(404)
            return
        ext = os.path.splitext(full)[1].lower()
        ctypes = {".css": "text/css", ".js": "application/javascript", ".png": "image/png",
                  ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".svg": "image/svg+xml", ".ico": "image/x-icon"}
        self.send_response(200)
        self.send_header("Content-Type", ctypes.get(ext, "application/octet-stream"))
        self.end_headers()
        with open(full, "rb") as f:
            self.wfile.write(f.read())

    def current_user(self):
        sid = self.get_cookie("session_id")
        sess = get_session(sid)
        if not sess:
            return None
        return get_user(sess["user_id"])

    def require_login(self):
        user = self.current_user()
        if not user:
            self.send_redirect("/login")
            return None
        return user

    def require_admin(self):
        user = self.require_login()
        if not user or not user.get("is_admin"):
            self.send_html("<h1>403 Forbidden</h1><p>Admin access only.</p>", 403)
            return None
        return user

    # ---------- ROUTES ----------
    def do_GET(self):
        path, query = self.parse_path()

        if path.startswith("/static/"):
            self.send_static(path)
            return

        user = self.current_user()

        if path == "/" or path == "/home":
            self.page_home(user)
        elif path == "/register":
            if user:
                self.send_redirect("/dashboard")
            else:
                self.page_register()
        elif path == "/login":
            if user:
                self.send_redirect("/dashboard")
            else:
                self.page_login()
        elif path == "/logout":
            sid = self.get_cookie("session_id")
            destroy_session(sid)
            self.send_response(302)
            self.clear_cookie("session_id")
            self.send_header("Location", "/")
            self.end_headers()
        elif path == "/dashboard":
            u = self.require_login()
            if u:
                self.page_dashboard(u)
        elif path == "/task":
            u = self.require_login()
            if u:
                tid = query.get("id", [None])[0]
                self.page_task(u, tid)
        elif path == "/earnings":
            u = self.require_login()
            if u:
                self.page_earnings(u)
        elif path == "/packages":
            u = self.require_login()
            if u:
                self.page_packages(u)
        elif path == "/pay":
            u = self.require_login()
            if u:
                pkg = query.get("package", ["bronze"])[0]
                self.page_pay(u, pkg)
        elif path == "/payment-form":
            u = self.require_login()
            if u:
                pkg = query.get("package", ["bronze"])[0]
                self.page_payment_form(u, pkg)
        elif path == "/marketplace":
            u = self.require_login()
            if u:
                self.page_marketplace(u)
        elif path == "/withdraw":
            u = self.require_login()
            if u:
                self.page_withdraw(u)
        elif path == "/profile":
            u = self.require_login()
            if u:
                self.page_profile(u)
        elif path == "/admin":
            u = self.require_admin()
            if u:
                self.page_admin(u)
        elif path == "/admin/users":
            u = self.require_admin()
            if u:
                self.page_admin_users(u)
        elif path == "/admin/payments":
            u = self.require_admin()
            if u:
                self.page_admin_payments(u)
        elif path == "/admin/submissions":
            u = self.require_admin()
            if u:
                self.page_admin_submissions(u)
        elif path == "/admin/withdrawals":
            u = self.require_admin()
            if u:
                self.page_admin_withdrawals(u)
        else:
            self.send_html("<h1>404 Not Found</h1><a href='/'>Home</a>", 404)

    def do_POST(self):
        path, query = self.parse_path()
        data = self.get_post_data()

        # Helper to get single value from parse_qs
        def g(key, default=""):
            v = data.get(key, [default])
            return v[0] if isinstance(v, list) else v

        if path == "/register":
            self.handle_register(data)
        elif path == "/login":
            self.handle_login(data)
        elif path == "/submit-task":
            u = self.require_login()
            if u:
                self.handle_submit_task(u, data)
        elif path == "/submit-payment":
            u = self.require_login()
            if u:
                self.handle_submit_payment(u, data)
        elif path == "/request-withdrawal":
            u = self.require_login()
            if u:
                self.handle_withdrawal(u, data)
        elif path == "/admin/verify-payment":
            u = self.require_admin()
            if u:
                self.handle_admin_verify_payment(data)
        elif path == "/admin/review-submission":
            u = self.require_admin()
            if u:
                self.handle_admin_review_submission(data)
        elif path == "/admin/process-withdrawal":
            u = self.require_admin()
            if u:
                self.handle_admin_process_withdrawal(data)
        else:
            self.send_html("<h1>404</h1>", 404)

    # ---------- PAGE RENDERERS ----------
    def page_home(self, user):
        nav = self._nav(user)
        html_content = render_template("home.html", nav=nav, user_name=user["full_name"] if user else "")
        self.send_html(html_content)

    def page_register(self):
        html_content = render_template("register.html", nav=self._nav(None), error="", success="")
        self.send_html(html_content)

    def page_login(self):
        html_content = render_template("login.html", nav=self._nav(None), error="")
        self.send_html(html_content)

    def page_dashboard(self, user):
        conn = get_db()
        tasks = conn.execute("SELECT * FROM tasks WHERE is_initial = 1 AND is_active = 1").fetchall()
        # Check which already submitted
        submitted = set()
        for r in conn.execute("SELECT task_id FROM task_submissions WHERE user_id = ?", (user["id"],)).fetchall():
            submitted.add(r["task_id"])
        conn.close()

        task_cards = ""
        for t in tasks:
            done = t["id"] in submitted
            btn = f'<span class="badge badge-success">Submitted</span>' if done else f'<a href="/task?id={t["id"]}" class="btn btn-primary">START TASK</a>'
            task_cards += f"""
            <div class="task-card">
                <div class="task-cat">{html.escape(t['category'])}</div>
                <h3>{html.escape(t['title'])}</h3>
                <p class="task-reward">${t['reward_usd']:.0f} Reward</p>
                <p class="task-instr">{html.escape(t['instructions'][:120])}...</p>
                <p class="task-req"><strong>Requirements:</strong> {html.escape(t['requirements'] or '')}</p>
                {btn}
            </div>
            """
        html_content = render_template("dashboard.html",
                                       nav=self._nav(user),
                                       user_name=html.escape(user["full_name"]),
                                       task_cards=task_cards,
                                       package=user.get("package", "none").upper())
        self.send_html(html_content)

    def page_task(self, user, tid):
        if not tid:
            self.send_redirect("/dashboard")
            return
        conn = get_db()
        task = conn.execute("SELECT * FROM tasks WHERE id = ?", (tid,)).fetchone()
        existing = conn.execute("SELECT * FROM task_submissions WHERE user_id = ? AND task_id = ?",
                                (user["id"], tid)).fetchone()
        conn.close()
        if not task:
            self.send_html("<h1>Task not found</h1>", 404)
            return
        if existing:
            self.send_html(render_template("task_already.html",
                                           nav=self._nav(user),
                                           title=html.escape(task["title"]),
                                           status=existing["status"]))
            return
        html_content = render_template("task.html",
                                       nav=self._nav(user),
                                       task_id=task["id"],
                                       title=html.escape(task["title"]),
                                       instructions=html.escape(task["instructions"]),
                                       reward=f"{task['reward_usd']:.0f}",
                                       requirements=html.escape(task["requirements"] or ""))
        self.send_html(html_content)

    def page_earnings(self, user):
        summary = get_earnings_summary(user["id"])
        total_potential = 76.0
        completed = user_completed_initial(user["id"])
        remaining = max(0, 100 - summary["withdrawable"])
        msg = ""
        if summary["withdrawable"] < 100:
            msg = f"""<div class="alert alert-warning">
                Your earnings are currently below the minimum withdrawal amount of $100.
                Complete additional eligible tasks to reach the withdrawal threshold.
                <br><strong>Remaining needed: ${remaining:.0f}</strong>
                <br><br><a href="/packages" class="btn btn-gold">ACCESS MORE TASKS</a>
            </div>"""
        html_content = render_template("earnings.html",
                                       nav=self._nav(user),
                                       pending=f"{summary['pending']:.2f}",
                                       approved=f"{summary['approved']:.2f}",
                                       withdrawable=f"{summary['withdrawable']:.2f}",
                                       paid=f"{summary['paid']:.2f}",
                                       total_potential="76",
                                       threshold_msg=msg,
                                       package=user.get("package", "none").upper())
        self.send_html(html_content)

    def page_packages(self, user):
        html_content = render_template("packages.html",
                                       nav=self._nav(user),
                                       current_package=user.get("package", "none").upper())
        self.send_html(html_content)

    def page_pay(self, user, pkg):
        prices = {"bronze": 150, "premium": 392, "gold": 706}
        pkg = pkg.lower()
        if pkg not in prices:
            pkg = "bronze"
        price = prices[pkg]
        html_content = render_template("pay.html",
                                       nav=self._nav(user),
                                       package=pkg.upper(),
                                       package_lower=pkg,
                                       price=price,
                                       till="5656584")
        self.send_html(html_content)

    def page_payment_form(self, user, pkg):
        prices = {"bronze": 150, "premium": 392, "gold": 706}
        pkg = pkg.lower()
        if pkg not in prices:
            pkg = "bronze"
        html_content = render_template("payment_form.html",
                                       nav=self._nav(user),
                                       package=pkg.upper(),
                                       package_lower=pkg,
                                       price=prices[pkg],
                                       full_name=html.escape(user["full_name"]),
                                       phone=html.escape(user["phone"]))
        self.send_html(html_content)

    def page_marketplace(self, user):
        if user.get("package") == "none" or not user.get("package_activated"):
            self.send_html(render_template("need_package.html", nav=self._nav(user)))
            return
        conn = get_db()
        tasks = conn.execute("SELECT * FROM tasks WHERE is_initial = 0 AND is_active = 1").fetchall()
        submitted = {r["task_id"] for r in conn.execute(
            "SELECT task_id FROM task_submissions WHERE user_id = ?", (user["id"],)).fetchall()}
        conn.close()
        cards = ""
        for t in tasks:
            done = t["id"] in submitted
            btn = '<span class="badge badge-success">Applied / Submitted</span>' if done else f'<a href="/task?id={t["id"]}" class="btn btn-primary">APPLY</a>'
            cards += f"""
            <div class="task-card">
                <div class="task-cat">{html.escape(t['category'])}</div>
                <h3>{html.escape(t['title'])}</h3>
                <p class="task-reward">${t['reward_usd']:.0f}</p>
                <p>{html.escape(t['instructions'][:100])}...</p>
                <p><small>Deadline: {t['deadline_hours']} hours | {html.escape(t['requirements'] or '')}</small></p>
                {btn}
            </div>
            """
        html_content = render_template("marketplace.html",
                                       nav=self._nav(user),
                                       task_cards=cards)
        self.send_html(html_content)

    def page_withdraw(self, user):
        summary = get_earnings_summary(user["id"])
        can_withdraw = summary["withdrawable"] >= 100
        html_content = render_template("withdraw.html",
                                       nav=self._nav(user),
                                       balance=f"{summary['withdrawable']:.2f}",
                                       full_name=html.escape(user["full_name"]),
                                       phone=html.escape(user["phone"]),
                                       can_withdraw="true" if can_withdraw else "false",
                                       min_msg="" if can_withdraw else '<div class="alert alert-danger">Minimum withdrawal is $100 USD. Current withdrawable balance is insufficient.</div>')
        self.send_html(html_content)

    def page_profile(self, user):
        html_content = render_template("profile.html",
                                       nav=self._nav(user),
                                       full_name=html.escape(user["full_name"]),
                                       email=html.escape(user["email"]),
                                       phone=html.escape(user["phone"]),
                                       package=user.get("package", "none").upper(),
                                       activated="Yes" if user.get("package_activated") else "No")
        self.send_html(html_content)

    def page_admin(self, user):
        conn = get_db()
        stats = {
            "users": conn.execute("SELECT COUNT(*) FROM users").fetchone()[0],
            "pending_payments": conn.execute("SELECT COUNT(*) FROM payments WHERE status='pending'").fetchone()[0],
            "pending_subs": conn.execute("SELECT COUNT(*) FROM task_submissions WHERE status='pending'").fetchone()[0],
            "pending_wd": conn.execute("SELECT COUNT(*) FROM withdrawals WHERE status='pending'").fetchone()[0],
        }
        conn.close()
        html_content = render_template("admin.html",
                                       nav=self._nav(user),
                                       stats_users=stats["users"],
                                       stats_payments=stats["pending_payments"],
                                       stats_subs=stats["pending_subs"],
                                       stats_wd=stats["pending_wd"])
        self.send_html(html_content)

    def page_admin_users(self, user):
        conn = get_db()
        rows = conn.execute("SELECT id, full_name, email, phone, package, package_activated, created_at FROM users ORDER BY id DESC").fetchall()
        conn.close()
        table = ""
        for r in rows:
            table += f"<tr><td>{r['id']}</td><td>{html.escape(r['full_name'])}</td><td>{html.escape(r['email'])}</td><td>{html.escape(r['phone'])}</td><td>{r['package']}</td><td>{'Yes' if r['package_activated'] else 'No'}</td><td>{r['created_at']}</td></tr>"
        html_content = render_template("admin_users.html", nav=self._nav(user), table_rows=table)
        self.send_html(html_content)

    def page_admin_payments(self, user):
        conn = get_db()
        rows = conn.execute("""SELECT p.*, u.full_name as uname FROM payments p
                               JOIN users u ON p.user_id = u.id ORDER BY p.id DESC""").fetchall()
        conn.close()
        table = ""
        for r in rows:
            actions = ""
            if r["status"] == "pending":
                actions = f"""
                <form method="POST" action="/admin/verify-payment" style="display:inline">
                    <input type="hidden" name="id" value="{r['id']}">
                    <button name="action" value="verify" class="btn btn-sm btn-success">Verify</button>
                    <button name="action" value="reject" class="btn btn-sm btn-danger">Reject</button>
                </form>"""
            table += f"""<tr>
                <td>{r['id']}</td><td>{html.escape(r['uname'])}</td><td>{r['package']}</td>
                <td>KSh {r['amount_ksh']}</td><td>{html.escape(r['mpesa_code'] or '')}</td>
                <td>{r['status']}</td><td>{r['submitted_at']}</td><td>{actions}</td></tr>"""
        html_content = render_template("admin_payments.html", nav=self._nav(user), table_rows=table)
        self.send_html(html_content)

    def page_admin_submissions(self, user):
        conn = get_db()
        rows = conn.execute("""SELECT ts.*, u.full_name, t.title, t.reward_usd FROM task_submissions ts
                               JOIN users u ON ts.user_id = u.id
                               JOIN tasks t ON ts.task_id = t.id
                               ORDER BY ts.id DESC LIMIT 50""").fetchall()
        conn.close()
        table = ""
        for r in rows:
            actions = ""
            if r["status"] == "pending":
                actions = f"""
                <form method="POST" action="/admin/review-submission" style="display:inline">
                    <input type="hidden" name="id" value="{r['id']}">
                    <button name="action" value="approve" class="btn btn-sm btn-success">Approve</button>
                    <button name="action" value="reject" class="btn btn-sm btn-danger">Reject</button>
                </form>"""
            preview = html.escape((r["content"] or "")[:80]) + "..."
            table += f"""<tr>
                <td>{r['id']}</td><td>{html.escape(r['full_name'])}</td><td>{html.escape(r['title'])}</td>
                <td>${r['reward_usd']}</td><td>{r['status']}</td><td>{r['submitted_at']}</td>
                <td title="{html.escape(r['content'] or '')}">{preview}</td><td>{actions}</td></tr>"""
        html_content = render_template("admin_submissions.html", nav=self._nav(user), table_rows=table)
        self.send_html(html_content)

    def page_admin_withdrawals(self, user):
        conn = get_db()
        rows = conn.execute("""SELECT w.*, u.email FROM withdrawals w
                               JOIN users u ON w.user_id = u.id ORDER BY w.id DESC""").fetchall()
        conn.close()
        table = ""
        for r in rows:
            actions = ""
            if r["status"] in ("pending", "processing"):
                actions = f"""
                <form method="POST" action="/admin/process-withdrawal" style="display:inline">
                    <input type="hidden" name="id" value="{r['id']}">
                    <button name="action" value="paid" class="btn btn-sm btn-success">Mark Paid</button>
                    <button name="action" value="reject" class="btn btn-sm btn-danger">Reject</button>
                </form>"""
            table += f"""<tr>
                <td>{r['id']}</td><td>{html.escape(r['full_name'])}</td><td>{html.escape(r['mpesa_phone'])}</td>
                <td>${r['amount_usd']:.2f}</td><td>{r['status']}</td><td>{r['requested_at']}</td><td>{actions}</td></tr>"""
        html_content = render_template("admin_withdrawals.html", nav=self._nav(user), table_rows=table)
        self.send_html(html_content)

    def _nav(self, user):
        if user:
            admin_link = '<a href="/admin">Admin</a>' if user.get("is_admin") else ""
            return f"""
            <a href="/dashboard">Tasks</a>
            <a href="/earnings">Earnings</a>
            <a href="/marketplace">Marketplace</a>
            <a href="/packages">Packages</a>
            <a href="/withdraw">Withdraw</a>
            <a href="/profile">Profile</a>
            {admin_link}
            <a href="/logout" class="btn-outline">Logout</a>
            """
        return """
            <a href="/">Home</a>
            <a href="/login">Login</a>
            <a href="/register" class="btn-primary-nav">Register</a>
            """

    # ---------- HANDLERS ----------
    def handle_register(self, data):
        def g(k):
            v = data.get(k, [""])
            return v[0].strip() if isinstance(v, list) else str(v).strip()

        full_name = g("full_name")
        phone = g("phone")
        email = g("email")
        password = g("password")
        confirm = g("confirm_password")

        error = ""
        if not all([full_name, phone, email, password]):
            error = "All fields are required."
        elif password != confirm:
            error = "Passwords do not match."
        elif len(password) < 6:
            error = "Password must be at least 6 characters."
        else:
            conn = get_db()
            try:
                ph = hash_password(password)
                conn.execute("INSERT INTO users (full_name, phone, email, password_hash) VALUES (?, ?, ?, ?)",
                             (full_name, phone, email, ph))
                conn.commit()
                uid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
                conn.close()
                sid = create_session(uid)
                self.send_response(302)
                self.set_cookie("session_id", sid)
                self.send_header("Location", "/dashboard")
                self.end_headers()
                return
            except sqlite3.IntegrityError:
                error = "Email or phone number already registered."
            finally:
                conn.close()

        err_html = f'<div class="alert alert-danger">{html.escape(error)}</div>' if error else ""
        html_content = render_template("register.html", nav=self._nav(None), error=err_html, success="")
        self.send_html(html_content)

    def handle_login(self, data):
        def g(k):
            v = data.get(k, [""])
            return v[0].strip() if isinstance(v, list) else str(v).strip()
        email = g("email")
        password = g("password")
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        conn.close()
        if user and verify_password(password, user["password_hash"]):
            sid = create_session(user["id"])
            self.send_response(302)
            self.set_cookie("session_id", sid)
            self.send_header("Location", "/dashboard")
            self.end_headers()
        else:
            err_html = '<div class="alert alert-danger">Invalid email or password.</div>'
            html_content = render_template("login.html", nav=self._nav(None), error=err_html)
            self.send_html(html_content)

    def handle_submit_task(self, user, data):
        def g(k):
            v = data.get(k, [""])
            return v[0] if isinstance(v, list) else str(v)
        task_id = g("task_id")
        content = g("content").strip()
        if not content or len(content) < 50:
            self.send_html("<h1>Content too short</h1><a href='javascript:history.back()'>Back</a>")
            return
        word_count = len(content.split())
        conn = get_db()
        try:
            # Prevent duplicate
            existing = conn.execute("SELECT id FROM task_submissions WHERE user_id=? AND task_id=?",
                                    (user["id"], task_id)).fetchone()
            if existing:
                conn.close()
                self.send_redirect("/dashboard")
                return
            cur = conn.execute("""INSERT INTO task_submissions (user_id, task_id, content, word_count, status)
                                  VALUES (?, ?, ?, ?, 'pending')""",
                               (user["id"], task_id, content, word_count))
            sub_id = cur.lastrowid
            task = conn.execute("SELECT reward_usd FROM tasks WHERE id=?", (task_id,)).fetchone()
            if task:
                conn.execute("""INSERT INTO earnings (user_id, task_id, submission_id, amount_usd, status)
                                VALUES (?, ?, ?, ?, 'pending')""",
                             (user["id"], task_id, sub_id, task["reward_usd"]))
            conn.commit()
        except Exception as e:
            conn.rollback()
            self.send_html(f"<h1>Error</h1><p>{e}</p>")
            return
        finally:
            conn.close()
        html_content = render_template("submit_success.html",
                                       nav=self._nav(user),
                                       word_count=word_count)
        self.send_html(html_content)

    def handle_submit_payment(self, user, data):
        def g(k):
            v = data.get(k, [""])
            return v[0].strip() if isinstance(v, list) else str(v).strip()
        package = g("package").lower()
        amount = float(g("amount") or 0)
        mpesa_code = g("mpesa_code")
        phone = g("phone")
        full_name = g("full_name")
        prices = {"bronze": 150, "premium": 392, "gold": 706}
        if package not in prices or amount != prices[package]:
            self.send_html("<h1>Invalid package/amount</h1>")
            return
        conn = get_db()
        conn.execute("""INSERT INTO payments (user_id, package, amount_ksh, mpesa_code, phone, full_name, status)
                        VALUES (?, ?, ?, ?, ?, ?, 'pending')""",
                     (user["id"], package, amount, mpesa_code, phone, full_name))
        conn.commit()
        conn.close()
        html_content = render_template("payment_submitted.html", nav=self._nav(user))
        self.send_html(html_content)

    def handle_withdrawal(self, user, data):
        def g(k):
            v = data.get(k, [""])
            return v[0].strip() if isinstance(v, list) else str(v).strip()
        amount = float(g("amount") or 0)
        mpesa_phone = g("mpesa_phone")
        full_name = g("full_name")
        summary = get_earnings_summary(user["id"])
        if amount < 100 or amount > summary["withdrawable"]:
            self.send_html("<h1>Invalid amount. Minimum $100 and within available balance.</h1><a href='/withdraw'>Back</a>")
            return
        conn = get_db()
        conn.execute("""INSERT INTO withdrawals (user_id, full_name, mpesa_phone, amount_usd, status)
                        VALUES (?, ?, ?, ?, 'pending')""",
                     (user["id"], full_name, mpesa_phone, amount))
        # Move from approved to pending withdrawal tracking (simplified: leave earnings as is, admin will mark paid)
        conn.commit()
        conn.close()
        html_content = render_template("withdraw_success.html", nav=self._nav(user), amount=f"{amount:.2f}")
        self.send_html(html_content)

    def handle_admin_verify_payment(self, data):
        def g(k):
            v = data.get(k, [""])
            return v[0] if isinstance(v, list) else str(v)
        pid = g("id")
        action = g("action")
        conn = get_db()
        payment = conn.execute("SELECT * FROM payments WHERE id=?", (pid,)).fetchone()
        if payment and payment["status"] == "pending":
            if action == "verify":
                conn.execute("UPDATE payments SET status='verified', verified_at=CURRENT_TIMESTAMP WHERE id=?", (pid,))
                conn.execute("UPDATE users SET package=?, package_activated=1 WHERE id=?",
                             (payment["package"], payment["user_id"]))
            else:
                conn.execute("UPDATE payments SET status='rejected', verified_at=CURRENT_TIMESTAMP WHERE id=?", (pid,))
            conn.commit()
        conn.close()
        self.send_redirect("/admin/payments")

    def handle_admin_review_submission(self, data):
        def g(k):
            v = data.get(k, [""])
            return v[0] if isinstance(v, list) else str(v)
        sid = g("id")
        action = g("action")
        conn = get_db()
        sub = conn.execute("SELECT * FROM task_submissions WHERE id=?", (sid,)).fetchone()
        if sub and sub["status"] == "pending":
            new_status = "approved" if action == "approve" else "rejected"
            conn.execute("UPDATE task_submissions SET status=?, reviewed_at=CURRENT_TIMESTAMP WHERE id=?",
                         (new_status, sid))
            # Update earnings
            earn_status = "approved" if action == "approve" else "pending"  # keep pending or could mark rejected
            if action == "approve":
                conn.execute("UPDATE earnings SET status='approved' WHERE submission_id=?", (sid,))
            conn.commit()
        conn.close()
        self.send_redirect("/admin/submissions")

    def handle_admin_process_withdrawal(self, data):
        def g(k):
            v = data.get(k, [""])
            return v[0] if isinstance(v, list) else str(v)
        wid = g("id")
        action = g("action")
        conn = get_db()
        wd = conn.execute("SELECT * FROM withdrawals WHERE id=?", (wid,)).fetchone()
        if wd and wd["status"] in ("pending", "processing"):
            if action == "paid":
                conn.execute("UPDATE withdrawals SET status='paid', processed_at=CURRENT_TIMESTAMP WHERE id=?", (wid,))
                # Reduce approved earnings (simplified: mark some as paid)
                conn.execute("""UPDATE earnings SET status='paid' WHERE user_id=? AND status='approved'
                                AND id IN (SELECT id FROM earnings WHERE user_id=? AND status='approved' LIMIT 1)""",
                             (wd["user_id"], wd["user_id"]))  # simplistic
            else:
                conn.execute("UPDATE withdrawals SET status='rejected', processed_at=CURRENT_TIMESTAMP WHERE id=?", (wid,))
            conn.commit()
        conn.close()
        self.send_redirect("/admin/withdrawals")


def main():
    init_db()
    print(f"Starting Freelancing Platform on http://{HOST}:{PORT}")
    print("Default admin: admin@platform.local / admin123")
    server = HTTPServer((HOST, PORT), PlatformHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
        server.server_close()

if __name__ == "__main__":
    main()
